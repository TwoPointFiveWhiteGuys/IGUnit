# Image classification demo

## Physical Setup

-   VisionHat installed on a Raspberry Pi Zero
-   Servo connected to vision hat (signal - PIN_A, Vcc - POWER, Ground - GND)
    -   Servo mounted in label display
-   (optional) Monitor connected to raspberry pi.
